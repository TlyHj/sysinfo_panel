# sysinfo (desktop)

Windows 优先的桌面版入口。

## 目录

- `panel/`：Web 面板（基于 sysinfo-panel，作为内置服务启动）
- `desktop/`：桌面壳（Electron）

## 本地运行（Windows）

1) 安装依赖

```powershell
cd desktop
npm i
```

2) 启动

```powershell
npm start
```

启动后会自动拉起内置面板，并在窗口内打开。
