const { app, BrowserWindow, Tray, Menu, nativeImage, Notification } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const { wait } = require('./wait-ready');

let win;
let tray;
let child;

const PANEL_DIR = path.join(__dirname, '..', 'panel');
const PANEL_HOST = process.env.PANEL_HOST || '127.0.0.1';
const PANEL_PORT = Number.parseInt(process.env.PANEL_PORT || '18888', 10);
const PANEL_BASE = process.env.PANEL_BASE || '/sysinfo';
const PANEL_URL = `http://${PANEL_HOST}:${PANEL_PORT}${PANEL_BASE}`;

function startPanel() {
  // Start node server as a child process (Windows-friendly)
  const electron = process.execPath;
  const serverPath = path.join(PANEL_DIR, 'server.js');
  // Use Electron's embedded Node runtime
  child = spawn(electron, ['--run-as-node', serverPath], {
    cwd: PANEL_DIR,
    env: {
      ...process.env,
      HOST: PANEL_HOST,
      PORT: String(PANEL_PORT),
      BASE_PATH: PANEL_BASE,
    },
    stdio: 'ignore',
    windowsHide: true,
  });
}

function stopPanel() {
  if (!child) return;
  try { child.kill(); } catch {}
  child = null;
}

async function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 820,
    backgroundColor: '#050814',
    title: 'SysInfo',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
    },
  });

  // Wait for server to be ready before loading UI (Windows cold start friendly)
  const ready = await wait(PANEL_URL, 50, 200);
  win.loadURL(ready ? PANEL_URL : `data:text/html,${encodeURIComponent('<h3 style="font-family:system-ui;color:#e5edf7;background:#050814;padding:24px;">SysInfo 启动中…</h3><p style="font-family:system-ui;color:#9fb0cb;padding:0 24px;">面板服务未就绪，稍后请刷新。</p>')}`);

  win.on('close', (e) => {
    // minimize to tray
    if (!app.isQuiting) {
      e.preventDefault();
      win.hide();
      try {
        if (Notification.isSupported()) {
          new Notification({ title: 'SysInfo', body: '已最小化到托盘' }).show();
        }
      } catch {}
    }
  });
}

function createTray() {
  const iconPath = path.join(__dirname, 'assets', 'tray.png');
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon.isEmpty() ? undefined : icon);
  const menu = Menu.buildFromTemplate([
    { label: '打开', click: () => { win.show(); } },
    { label: '刷新', click: () => { try { win.reload(); } catch {} } },
    { type: 'separator' },
    { label: '退出', click: () => { app.isQuiting = true; app.quit(); } },
  ]);
  tray.setToolTip('SysInfo');
  tray.setContextMenu(menu);
  tray.on('double-click', () => win.show());
}

app.whenReady().then(async () => {
  startPanel();
  await createWindow();
  createTray();
});

app.on('before-quit', () => {
  app.isQuiting = true;
});

app.on('will-quit', () => {
  stopPanel();
});

app.on('window-all-closed', () => {
  // keep running in tray on Windows
  // do nothing
});
