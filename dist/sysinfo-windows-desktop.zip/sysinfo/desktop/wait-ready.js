const http = require('http');

function check(url, timeoutMs = 700) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout: timeoutMs }, (res) => {
      res.resume();
      resolve(res.statusCode && res.statusCode >= 200 && res.statusCode < 500);
    });
    req.on('timeout', () => { try { req.destroy(); } catch {} resolve(false); });
    req.on('error', () => resolve(false));
  });
}

async function wait(url, tries = 40, gapMs = 250) {
  for (let i = 0; i < tries; i++) {
    // eslint-disable-next-line no-await-in-loop
    const ok = await check(url);
    if (ok) return true;
    // eslint-disable-next-line no-await-in-loop
    await new Promise(r => setTimeout(r, gapMs));
  }
  return false;
}

module.exports = { wait };
